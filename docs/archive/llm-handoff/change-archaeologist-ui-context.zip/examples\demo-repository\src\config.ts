export function loadConfig(raw: string | null): Record<string, unknown> {
  if (!raw) {
    return {};
  }
  return JSON.parse(raw);
}
