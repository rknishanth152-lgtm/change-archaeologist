/**
 * Navbar Component
 *
 * Evidence Atlas Two-Level Application Header:
 * - Level 1 (Primary Navigation): Brand identity, console tag, Evidence Atlas descriptor,
 *   Guide toggle, and prominent Import JSON action.
 * - Level 2 (Report Context): Target file/function, BASE-to-HEAD revision comparison,
 *   analysis status badge, and demonstration scenario selector.
 *
 * Integrated UI Components retrieved from:
 * - https://buttons.ibelick.com/ (Tactile Micro-Interaction Buttons)
 * - https://ui.shadcn.com/r/styles/default/badge.json (Status Badges)
 */

import React from "react";
import { Search, Upload, CheckCircle2, AlertCircle, FileCode, GitCommit, HelpCircle } from "lucide-react";
import type { AnalysisReport } from "../types/index.js";
import { DEMO_FIXTURES } from "../data/demo-fixtures.js";
import { TactileButton } from "./ui/TactileButton.js";
import { Badge } from "./ui/Badge.js";

interface NavbarProps {
  readonly report: AnalysisReport | null;
  readonly onLoadClick: () => void;
  readonly onSelectScenario: (scenarioId: string) => void;
  readonly activeScenarioId?: string | null;
  readonly onToggleGuide?: () => void;
  readonly isGuideOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  report,
  onLoadClick,
  onSelectScenario,
  activeScenarioId,
  onToggleGuide,
  isGuideOpen = false,
}) => {
  const isComplete = report?.status.startsWith("COMPLETED");

  return (
    <header
      role="banner"
      aria-label="Change Archaeologist Application Header"
      className="border-b border-hairline bg-panel select-none z-20 sticky top-0 flex flex-col"
    >
      {/* Level 1: Primary Navigation Row */}
      <div className="w-full px-4 py-2 flex items-center justify-between gap-3 border-b border-hairline shrink-0 min-h-[46px]">
        {/* Left: Brand Identity */}
        <div className="flex items-center space-x-2.5 min-w-0">
          <div
            className="flex items-center justify-center w-7 h-7 rounded-sm text-text-accent shrink-0"
            aria-hidden="true"
            style={{ border: "1px solid var(--border-hairline)", background: "var(--surface-elevated)" }}
          >
            <Search size={15} strokeWidth={1.5} />
          </div>
          <div className="flex items-baseline space-x-2 min-w-0">
            <h1
              className="font-display font-semibold text-sm text-text-primary m-0 p-0 truncate"
              style={{ letterSpacing: "-0.01em" }}
            >
              Change Archaeologist
            </h1>
            <Badge variant="sandstone" className="font-mono text-[9px] uppercase tracking-wider shrink-0 hidden xs:inline-flex">
              Console v1.0
            </Badge>
            <span className="hidden sm:inline-block font-mono text-[9px] text-text-accent uppercase tracking-widest opacity-80 shrink-0">
              evidence atlas
            </span>
          </div>
        </div>

        {/* Right: Primary Actions (Guide & Prominent Import JSON) */}
        <div className="flex items-center space-x-2 shrink-0">
          {onToggleGuide && (
            <TactileButton
              variant={isGuideOpen ? "secondary" : "outline"}
              size="sm"
              onClick={onToggleGuide}
              aria-expanded={isGuideOpen}
              aria-label={isGuideOpen ? "Close How to Read This Report Guide" : "Open How to Read This Report Guide"}
              icon={<HelpCircle size={12} strokeWidth={1.5} />}
              className="text-text-accent"
              title="How to Read This Report Guide"
            >
              <span className="hidden sm:inline">{isGuideOpen ? "Close Guide" : "Guide"}</span>
            </TactileButton>
          )}

          <TactileButton
            variant="primary"
            size="sm"
            onClick={onLoadClick}
            icon={<Upload size={12} strokeWidth={1.5} />}
            className="font-medium shadow-xs"
            aria-label="Import Analysis Report JSON"
          >
            <span>Import JSON</span>
          </TactileButton>
        </div>
      </div>

      {/* Level 2: Report Context & Scenario Preset Row */}
      <div className="w-full px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 text-xs font-mono bg-panel/75 shrink-0 min-h-[36px]">
        {/* Left / Center Context Metadata */}
        <div className="flex flex-wrap items-center gap-2 min-w-0 flex-1">
          {report ? (
            <>
              {/* Target File & Function */}
              <div
                className="flex items-center space-x-1.5 px-2 py-0.5 text-text-secondary min-w-0 max-w-full sm:max-w-md truncate"
                style={{ background: "var(--surface-ground)", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius-sm)" }}
                title={`${report.request.targetFilePath}:${report.request.targetFunctionName}`}
              >
                <FileCode size={11} strokeWidth={1.5} className="text-text-muted shrink-0" />
                <span className="text-text-muted truncate">{report.request.targetFilePath}:</span>
                <span className="text-text-primary font-medium shrink-0">{report.request.targetFunctionName}</span>
              </div>

              {/* Commit Range Comparison */}
              <div
                className="flex items-center space-x-1.5 px-2 py-0.5 text-text-muted shrink-0"
                style={{ background: "var(--surface-ground)", border: "1px solid var(--border-hairline)", borderRadius: "var(--radius-sm)" }}
                title={`Analyzing revisions ${report.baseCommit.shortSha} to ${report.headCommit.shortSha}`}
              >
                <GitCommit size={11} strokeWidth={1.5} />
                <span className="text-text-secondary tabular-nums">{report.baseCommit.shortSha}</span>
                <span className="text-text-muted">→</span>
                <span className="text-text-secondary tabular-nums">{report.headCommit.shortSha}</span>
              </div>

              {/* Static Analysis Status Badge */}
              <Badge
                variant={isComplete ? "verdigris" : "amber"}
                dot
                className="shrink-0"
              >
                {isComplete ? <CheckCircle2 size={11} strokeWidth={1.5} /> : <AlertCircle size={11} strokeWidth={1.5} />}
                <span>[{report.status}]</span>
              </Badge>
            </>
          ) : (
            <div className="flex items-center space-x-2 text-text-muted text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-text-muted shrink-0" aria-hidden="true" />
              <span>Standby — Ingest a JSON report or choose a demonstration scenario</span>
            </div>
          )}
        </div>

        {/* Right: Demonstration Scenario Preset Switcher */}
        <div className="flex items-center space-x-2 shrink-0 ml-auto sm:ml-0">
          <label htmlFor="scenario-preset-select" className="text-[10px] text-text-muted hidden md:inline uppercase tracking-wider">
            Demo Preset:
          </label>
          <select
            id="scenario-preset-select"
            value={activeScenarioId ?? ""}
            onChange={(e) => {
              if (e.target.value) onSelectScenario(e.target.value);
            }}
            className="h-6.5 px-2 text-[11px] font-mono text-text-secondary transition-colors duration-fast focus:outline-none focus-visible:ring-2 focus-visible:ring-border-focus cursor-pointer"
            style={{
              background: "var(--surface-ground)",
              border: "1px solid var(--border-hairline)",
              borderRadius: "var(--radius-sm)",
            }}
            aria-label="Select demonstration scenario"
          >
            <option value="" disabled>Select Demo Scenario…</option>
            {DEMO_FIXTURES.map((f) => (
              <option key={f.id} value={f.id}>
                Scenario {f.id}: {f.report.request.targetFunctionName} ({f.id})
              </option>
            ))}
          </select>
        </div>
      </div>
    </header>
  );
};
