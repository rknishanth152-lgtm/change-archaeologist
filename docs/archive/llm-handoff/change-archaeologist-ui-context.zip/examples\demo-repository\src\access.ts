export function authorizeUser(user: { isAdmin: boolean; isOwner: boolean }): boolean {
  if (user.isAdmin || user.isOwner) {
    return true;
  }
  return false;
}
