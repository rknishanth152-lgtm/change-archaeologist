import React, { memo } from "react";
import { Handle, Position } from "@xyflow/react";
import {
  Code,
  Layers,
  FileCode2,
  FileCheck,
  Tag,
} from "lucide-react";
import type { CorrelationGraphNodeData } from "../../types/index.js";
import { formatSpanCoordinates } from "../../utils/source-location.js";
import { Badge } from "../ui/Badge.js";

// Badge helper for change type
function renderChangeBadge(changeType?: string) {
  if (!changeType) return null;
  if (changeType === "ADDED") {
    return <Badge variant="verdigris" dot className="text-[9px] px-1.5 py-0 font-semibold">[+] ADD</Badge>;
  }
  if (changeType === "MODIFIED") {
    return <Badge variant="terracotta" dot className="text-[9px] px-1.5 py-0 font-semibold">[Δ] MOD</Badge>;
  }
  if (changeType === "REMOVED" || changeType === "DELETED") {
    return <Badge variant="amber" dot className="text-[9px] px-1.5 py-0 font-semibold">[-] REM</Badge>;
  }
  return null;
}

// Badge helper for correlation status
function renderCorrelationBadge(status?: string | null) {
  if (!status) return null;
  if (status === "STRONG") {
    return <Badge variant="verdigris" className="text-[9px] px-1.5 py-0 font-semibold">STRONG</Badge>;
  }
  if (status === "WEAK") {
    return <Badge variant="terracotta" className="text-[9px] px-1.5 py-0 font-semibold">WEAK</Badge>;
  }
  if (status === "UNCERTAIN") {
    return <Badge variant="amber" className="text-[9px] px-1.5 py-0 font-semibold">UNCERTAIN</Badge>;
  }
  return null;
}

// Shared node base style
function getNodeStyle(selected: boolean, borderColor?: string): React.CSSProperties {
  return {
    width: 240,
    minWidth: 240,
    maxWidth: 240,
    padding: "10px 12px",
    background: selected ? "var(--surface-elevated)" : "var(--surface-panel)",
    border: `1px solid ${selected ? (borderColor ?? "var(--text-accent)") : "var(--border-hairline)"}`,
    borderRadius: "3px",
    boxShadow: selected ? "0 0 0 2px rgba(196,82,26,0.15)" : "0 1px 3px rgba(90,70,50,0.08)",
    transition: "border-color 150ms, box-shadow 150ms",
    textAlign: "left" as const,
  };
}

// Handle style
const handleStyle: React.CSSProperties = {
  width: "8px",
  height: "8px",
  background: "var(--border-interactive)",
  border: "1px solid var(--surface-ground)",
  borderRadius: "1px",
};

// 1. Production Function Node
export const ProductionFunctionNode = memo(({ data, selected }: { data: CorrelationGraphNodeData; selected?: boolean }) => {
  const isDeleted = data.functionStatus === "DELETED";
  const spanStr = data.span ? formatSpanCoordinates(data.span) : null;

  return (
    <div
      role="treeitem"
      aria-label={`Production Function: ${data.title}`}
      style={{
        ...getNodeStyle(!!selected, "var(--text-accent)"),
        ...(isDeleted ? { borderColor: "var(--status-removed-border)", background: "var(--status-removed-bg)" } : {}),
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "6px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <Code size={11} style={{ color: "var(--text-accent)" }} />
          <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
            Target Fn
          </span>
        </div>
        {isDeleted ? (
          <span className="font-mono font-semibold" style={{ fontSize: "9px", padding: "1px 5px", borderRadius: "1px", color: "var(--status-removed-fg)", background: "var(--status-removed-bg)", border: "1px solid var(--status-removed-border)" }}>
            DELETED
          </span>
        ) : (
          <span className="font-mono" style={{ fontSize: "9px", padding: "1px 5px", borderRadius: "1px", color: "var(--text-muted)", background: "var(--surface-ground)", border: "1px solid var(--border-hairline)" }}>
            OBSERVED
          </span>
        )}
      </div>

      <div className="font-mono font-semibold truncate" style={{ fontSize: "12px", color: "var(--text-primary)" }} title={data.title}>
        {data.title}
      </div>
      <div className="font-mono truncate" style={{ fontSize: "10px", color: "var(--text-muted)", marginTop: "2px" }} title={data.filePath}>
        {data.filePath}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "8px", paddingTop: "6px", borderTop: "1px solid var(--border-hairline)" }}>
        <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)" }}>{spanStr ?? "File Root"}</span>
        <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)", textTransform: "uppercase" }}>Production</span>
      </div>

      <Handle id="source-right" type="source" position={Position.Right} style={{ ...handleStyle, background: "var(--text-accent)" }} />
    </div>
  );
});

// 2. Structural Change Node
export const StructuralChangeNode = memo(({ data, selected }: { data: CorrelationGraphNodeData; selected?: boolean }) => {
  const spanStr = data.span ? formatSpanCoordinates(data.span) : null;

  return (
    <div
      role="treeitem"
      aria-label={`Structural Change: ${data.title}`}
      style={getNodeStyle(!!selected, "var(--status-modified-border)")}
    >
      <Handle id="target-left" type="target" position={Position.Left} style={handleStyle} />

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "5px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <Layers size={11} style={{ color: "var(--status-modified-fg)" }} />
          <span className="font-mono font-semibold" style={{ fontSize: "11px", color: "var(--text-primary)" }}>{data.title}</span>
        </div>
        {renderChangeBadge(data.changeType)}
      </div>

      <div className="font-mono truncate" style={{ fontSize: "10px", color: "var(--text-secondary)" }} title={data.subtitle}>
        {data.subtitle}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "7px", paddingTop: "5px", borderTop: "1px solid var(--border-hairline)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
          {renderCorrelationBadge(data.correlationStatus) ?? (
            <span className="font-mono" style={{ fontSize: "9px", padding: "1px 5px", borderRadius: "1px", color: "var(--text-muted)", background: "var(--surface-ground)", border: "1px solid var(--border-hairline)" }}>
              UNLINKED
            </span>
          )}
          {spanStr && <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)", marginLeft: "2px" }}>{spanStr}</span>}
        </div>
        {data.evidenceIds.length > 0 && (
          <span className="font-mono font-semibold" style={{ fontSize: "9px", color: "var(--text-accent)" }}>
            {data.evidenceIds.length} EV
          </span>
        )}
      </div>

      <Handle id="source-right" type="source" position={Position.Right} style={{ ...handleStyle, background: "var(--text-accent)" }} />
    </div>
  );
});

// 3. Test Change Node
export const TestChangeNode = memo(({ data, selected }: { data: CorrelationGraphNodeData; selected?: boolean }) => {
  const spanStr = data.span ? formatSpanCoordinates(data.span) : null;

  return (
    <div
      role="treeitem"
      aria-label={`Test Change: ${data.title}`}
      style={getNodeStyle(!!selected, "var(--status-strong-border)")}
    >
      <Handle id="target-left" type="target" position={Position.Left} style={{ ...handleStyle, background: "var(--status-strong-fg)" }} />

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "5px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <FileCheck size={11} style={{ color: "var(--status-strong-fg)" }} />
          <span className="font-mono font-semibold" style={{ fontSize: "11px", color: "var(--text-primary)" }}>{data.title}</span>
        </div>
        {renderChangeBadge(data.changeType)}
      </div>

      <div className="font-mono truncate" style={{ fontSize: "10px", color: "var(--text-secondary)" }} title={data.subtitle}>
        {data.subtitle}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "7px", paddingTop: "5px", borderTop: "1px solid var(--border-hairline)" }}>
        <span className="font-mono truncate" style={{ fontSize: "9px", color: "var(--text-muted)", maxWidth: "130px" }} title={data.filePath}>
          {data.filePath.split("/").pop()} {spanStr ? `(${spanStr})` : ""}
        </span>
        {data.evidenceIds.length > 0 && (
          <span className="font-mono font-semibold" style={{ fontSize: "9px", color: "var(--text-accent)" }}>
            {data.evidenceIds.length} EV
          </span>
        )}
      </div>

      <Handle id="target-right" type="target" position={Position.Right} style={handleStyle} />
    </div>
  );
});

// 4. Test Declaration Node
export const TestDeclarationNode = memo(({ data, selected }: { data: CorrelationGraphNodeData; selected?: boolean }) => {
  const spanStr = data.span ? formatSpanCoordinates(data.span) : null;

  return (
    <div
      role="treeitem"
      aria-label={`Test Declaration: ${data.title}`}
      style={getNodeStyle(!!selected, "var(--status-weak-border)")}
    >
      <Handle id="target-left" type="target" position={Position.Left} style={{ ...handleStyle, background: "var(--status-weak-fg)" }} />

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "5px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <Tag size={11} style={{ color: "var(--status-weak-fg)" }} />
          <span className="font-mono font-semibold" style={{ fontSize: "11px", color: "var(--text-primary)" }}>{data.title}</span>
        </div>
        {renderChangeBadge(data.changeType)}
      </div>

      <div
        className="font-mono"
        style={{ fontSize: "10px", color: "var(--text-secondary)", lineHeight: 1.4, display: "-webkit-box", WebkitBoxOrient: "vertical", WebkitLineClamp: 2, overflow: "hidden" }}
        title={data.subtitle}
      >
        {data.subtitle}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "7px", paddingTop: "5px", borderTop: "1px solid var(--border-hairline)" }}>
        <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)" }}>{spanStr ?? "Declaration"}</span>
        <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)", textTransform: "uppercase" }}>Test Block</span>
      </div>

      <Handle id="target-right" type="target" position={Position.Right} style={handleStyle} />
    </div>
  );
});

// 5. Test File Node
export const TestFileNode = memo(({ data, selected }: { data: CorrelationGraphNodeData; selected?: boolean }) => {
  return (
    <div
      role="treeitem"
      aria-label={`Test File: ${data.title}`}
      style={getNodeStyle(!!selected, "var(--status-strong-border)")}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "6px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <FileCode2 size={11} style={{ color: "var(--status-strong-fg)" }} />
          <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
            Test Suite
          </span>
        </div>
        {renderChangeBadge(data.changeType)}
      </div>

      <div className="font-mono font-semibold truncate" style={{ fontSize: "12px", color: "var(--text-primary)" }} title={data.title}>
        {data.title}
      </div>
      <div className="font-mono truncate" style={{ fontSize: "10px", color: "var(--text-muted)", marginTop: "2px" }} title={data.filePath}>
        {data.filePath}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "8px", paddingTop: "6px", borderTop: "1px solid var(--border-hairline)" }}>
        <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)" }}>Companion Test File</span>
        <span className="font-mono" style={{ fontSize: "9px", color: "var(--text-muted)", textTransform: "uppercase" }}>Suite Root</span>
      </div>

      <Handle id="source-left" type="source" position={Position.Left} style={handleStyle} />
    </div>
  );
});
