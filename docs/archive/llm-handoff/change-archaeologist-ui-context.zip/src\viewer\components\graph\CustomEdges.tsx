import React, { memo } from "react";
import {
  BaseEdge,
  EdgeLabelRenderer,
  getBezierPath,
  getSmoothStepPath,
  type EdgeProps,
} from "@xyflow/react";
import type { CorrelationGraphEdgeData } from "../../types/index.js";

// Helper for status styling in Evidence Atlas palette
function getStatusStroke(status: string | null): string {
  switch (status) {
    case "STRONG":
      return "#1A5C2E"; // archival forest green
    case "WEAK":
      return "#5C3D99"; // archival purple
    case "UNCERTAIN":
      return "#9E6B00"; // archival ochre
    case "NONE":
    default:
      return "#8A7560"; // warm muted ink
  }
}

function getStatusBadgeStyle(status: string | null): React.CSSProperties {
  switch (status) {
    case "STRONG":
      return {
        color: "var(--status-strong-fg)",
        background: "var(--surface-panel)",
        border: "1px solid var(--status-strong-border)",
      };
    case "WEAK":
      return {
        color: "var(--status-weak-fg)",
        background: "var(--surface-panel)",
        border: "1px solid var(--status-weak-border)",
      };
    case "UNCERTAIN":
      return {
        color: "var(--status-uncertain-fg)",
        background: "var(--surface-panel)",
        border: "1px solid var(--status-uncertain-border)",
      };
    case "NONE":
    default:
      return {
        color: "var(--text-muted)",
        background: "var(--surface-panel)",
        border: "1px solid var(--border-hairline)",
      };
  }
}

function formatClassification(classification?: string | null): string {
  if (!classification) return "";
  switch (classification) {
    case "POTENTIALLY_RELATED_ASSERTION_MODIFIED":
      return "Assertion Modified";
    case "POTENTIALLY_RELATED_ASSERTION_ADDED":
      return "Assertion Added";
    case "POTENTIALLY_RELATED_ASSERTION_REMOVED":
      return "Assertion Removed";
    case "POTENTIALLY_RELATED_TEST_DECLARATION_CHANGED":
      return "Declaration Changed";
    case "TEMPORAL_CO_OCCURRENCE_ONLY":
      return "Temporal Co-occurrence";
    case "UNMODIFIED_COMPANION_TEST":
      return "Unmodified Companion";
    case "NO_TEST_CHANGES_OBSERVED":
      return "No Test Changes";
    case "NO_PRODUCTION_CHANGES_OBSERVED":
      return "No Production Changes";
    case "AMBIGUOUS_OR_UNRESOLVED":
      return "Ambiguous Match";
    default:
      return classification.replace(/_/g, " ").toLowerCase();
  }
}

// 1. Structural Containment Edge (Function -> Mutation, TestFile -> TestChange)
export const ContainmentEdge = memo((props: EdgeProps) => {
  const [edgePath] = getSmoothStepPath({
    sourceX: props.sourceX,
    sourceY: props.sourceY,
    sourcePosition: props.sourcePosition,
    targetX: props.targetX,
    targetY: props.targetY,
    targetPosition: props.targetPosition,
    borderRadius: 8,
  });

  return (
    <BaseEdge
      path={edgePath}
      style={{
        stroke: "rgba(90, 70, 50, 0.28)",
        strokeWidth: 1.5,
      }}
    />
  );
});

// 2. Cross-Side Correlation Edge (Structural Change <-> Test Change)
export const CorrelationEdge = memo((props: EdgeProps) => {
  const edgeData = props.data as unknown as CorrelationGraphEdgeData | undefined;
  const status = edgeData?.status ?? "NONE";
  const strokeColor = getStatusStroke(status);
  const isUncertain = status === "UNCERTAIN";
  const isNone = status === "NONE";

  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX: props.sourceX,
    sourceY: props.sourceY,
    sourcePosition: props.sourcePosition,
    targetX: props.targetX,
    targetY: props.targetY,
    targetPosition: props.targetPosition,
    curvature: 0.25,
  });

  return (
    <>
      <BaseEdge
        path={edgePath}
        style={{
          stroke: props.selected ? "var(--text-accent)" : strokeColor,
          strokeWidth: props.selected ? 3 : status === "STRONG" ? 2.5 : 2,
          strokeDasharray: isUncertain ? "6 4" : isNone ? "3 3" : undefined,
          filter: props.selected ? "drop-shadow(0 0 6px rgba(196, 82, 26, 0.45))" : undefined,
        }}
      />
      {edgeData && (
        <EdgeLabelRenderer>
          <div
            style={{
              position: "absolute",
              transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
              pointerEvents: "all",
            }}
            className="nodrag nopan"
          >
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
              }}
              style={{
                ...getStatusBadgeStyle(status),
                boxShadow: "0 2px 6px rgba(90, 70, 50, 0.12)",
                ...(props.selected ? { outline: "2px solid var(--border-focus)", outlineOffset: "1px" } : {}),
              }}
              className="px-2.5 py-1 rounded-sm font-mono text-[9px] font-semibold transition-all cursor-pointer flex flex-col items-center gap-0.5 select-none hover:brightness-95"
              title={`${edgeData.rationale ?? edgeData.label} (${edgeData.classification ?? "Analytical Link"})`}
            >
              <span>{edgeData.label}</span>
              {edgeData.classification && (
                <span className="text-[8px] font-normal opacity-85 uppercase tracking-tight">
                  {formatClassification(edgeData.classification)}
                </span>
              )}
            </button>
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  );
});
