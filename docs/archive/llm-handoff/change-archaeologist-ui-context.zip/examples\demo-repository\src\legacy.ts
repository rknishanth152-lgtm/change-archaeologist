// deprecatedHelper was removed in v1.1.0
export const LEGACY_VERSION = "0.0.1";
