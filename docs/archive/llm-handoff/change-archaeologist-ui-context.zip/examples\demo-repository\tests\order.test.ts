import { calculateDiscount } from "../src/order.js";

describe("order calculation", () => {
  it("calculates regular discount", () => {
    expect(calculateDiscount(100)).toBe(15);
  });
});
