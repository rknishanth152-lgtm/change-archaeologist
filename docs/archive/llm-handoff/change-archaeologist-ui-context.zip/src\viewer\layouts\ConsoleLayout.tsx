import React from "react";
import { GitCommit, Layers, FileCheck, Network, Scale, Workflow } from "lucide-react";
import { Navbar } from "../components/Navbar.js";
import { ExecutiveSummaryStrip } from "../components/ExecutiveSummaryStrip.js";
import { DetailInspector } from "../components/DetailInspector.js";
import { LimitationsBanner } from "../components/LimitationsBanner.js";
import { ReportReadingGuide } from "../components/ReportReadingGuide.js";
import type {
  AnalysisReport,
  WorkspaceTab,
  StructuralChange,
  TestChange,
  CorrelationItem,
  EvidenceItem,
} from "../types/index.js";

interface ConsoleLayoutProps {
  readonly report: AnalysisReport | null;
  readonly activeTab: WorkspaceTab;
  readonly onTabChange: (tab: WorkspaceTab) => void;
  readonly onLoadClick: () => void;
  readonly onSelectScenario: (scenarioId: string) => void;
  readonly activeScenarioId?: string | null;
  readonly selectedChange: StructuralChange | null;
  readonly selectedTestChange?: TestChange | null;
  readonly selectedCorrelation: CorrelationItem | null;
  readonly associatedEvidence: readonly EvidenceItem[];
  readonly selectedEvidenceId?: string | null;
  readonly onSelectEvidence?: (evidenceId: string) => void;
  readonly isGuideOpen?: boolean;
  readonly onToggleGuide?: () => void;
  readonly onCloseGuide?: () => void;
  readonly children: React.ReactNode;
}

const TAB_ORDER: WorkspaceTab[] = ["timeline", "graph", "structural", "tests", "correlations", "findings"];

const TAB_LABELS: Record<WorkspaceTab, string> = {
  timeline:     "Change Timeline view",
  graph:        "Correlation Graph view",
  structural:   "Structural Mutations view",
  tests:        "Test Changes view",
  correlations: "Correlation Matrix view",
  findings:     "Epistemic Findings view",
};

export const ConsoleLayout: React.FC<ConsoleLayoutProps> = ({
  report,
  activeTab,
  onTabChange,
  onLoadClick,
  onSelectScenario,
  activeScenarioId,
  selectedChange,
  selectedTestChange = null,
  selectedCorrelation,
  associatedEvidence,
  selectedEvidenceId,
  onSelectEvidence,
  isGuideOpen = false,
  onToggleGuide,
  onCloseGuide,
  children,
}) => {
  const [announcement, setAnnouncement] = React.useState<string>("");

  const handleTabKeyDown = (e: React.KeyboardEvent) => {
    const currentIndex = TAB_ORDER.indexOf(activeTab);
    if (currentIndex === -1) return;

    let nextIndex = -1;
    if (e.key === "ArrowRight") {
      nextIndex = (currentIndex + 1) % TAB_ORDER.length;
    } else if (e.key === "ArrowLeft") {
      nextIndex = (currentIndex - 1 + TAB_ORDER.length) % TAB_ORDER.length;
    } else if (e.key === "Home") {
      nextIndex = 0;
    } else if (e.key === "End") {
      nextIndex = TAB_ORDER.length - 1;
    }

    if (nextIndex !== -1) {
      e.preventDefault();
      const nextTab = TAB_ORDER[nextIndex];
      onTabChange(nextTab);
      document.getElementById(`tab-${nextTab}`)?.focus();
    }
  };

  React.useEffect(() => {
    if (report) {
      setAnnouncement(
        `Viewing ${TAB_LABELS[activeTab]} for ${report.request.targetFunctionName} (${report.request.targetFilePath}).`
      );
    }
  }, [activeTab, report]);

  const getTabCount = (tab: WorkspaceTab): number => {
    if (!report) return 0;
    switch (tab) {
      case "timeline":     return report.structuralChanges.length + report.testChanges.length + (report.declarationChanges?.length ?? 0);
      case "graph":        return report.correlationItems?.length ?? report.correlations.length;
      case "structural":   return report.structuralChanges.length;
      case "tests":        return report.testChanges.length;
      case "correlations": return report.correlationItems?.length ?? report.correlations.length;
      case "findings":     return report.findings.length;
    }
  };

  const tabIcons: Record<WorkspaceTab, React.ReactNode> = {
    timeline:     <GitCommit size={12} strokeWidth={1.5} />,
    graph:        <Workflow size={12} strokeWidth={1.5} />,
    structural:   <Layers size={12} strokeWidth={1.5} />,
    tests:        <FileCheck size={12} strokeWidth={1.5} />,
    correlations: <Network size={12} strokeWidth={1.5} />,
    findings:     <Scale size={12} strokeWidth={1.5} />,
  };

  const tabNames: Record<WorkspaceTab, { plain: string; technical: string }> = {
    timeline:     { plain: "What Changed",      technical: "Change Timeline" },
    graph:        { plain: "Relationships",     technical: "Correlation Graph" },
    structural:   { plain: "Code Changes",      technical: "Structural Mutations" },
    tests:        { plain: "Related Tests",     technical: "Companion Tests" },
    correlations: { plain: "Code–Test Links",   technical: "Correlation Matrix" },
    findings:     { plain: "What We Know",      technical: "Epistemic Findings" },
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--surface-ground)", color: "var(--text-primary)" }}>
      {/* Screen Reader Live Status Region */}
      <div role="status" aria-live="polite" aria-atomic="true" className="sr-only">
        {announcement}
      </div>

      {/* Top Navigation */}
      <Navbar
        report={report}
        onLoadClick={onLoadClick}
        onSelectScenario={onSelectScenario}
        activeScenarioId={activeScenarioId}
        onToggleGuide={onToggleGuide}
        isGuideOpen={isGuideOpen}
      />

      {/* Main Container */}
      {report ? (
        <div className="flex-1 flex flex-col min-h-0">
          {/* Executive Summary Strip */}
          <ExecutiveSummaryStrip
            report={report}
            isGuideOpen={isGuideOpen}
            onToggleGuide={onToggleGuide}
          />

          {/* How to Read This Report Guide (Dismissible) */}
          <ReportReadingGuide
            report={report}
            isOpen={isGuideOpen}
            onClose={onCloseGuide ?? onToggleGuide ?? (() => {})}
          />

          {/* Workspace Tabs Navigation */}
          <div
            role="tablist"
            aria-label="Analysis report workspace views"
            onKeyDown={handleTabKeyDown}
            className="flex items-center select-none z-10 overflow-x-auto shrink-0 font-mono text-xs"
            style={{
              height: "38px",
              borderBottom: "1px solid var(--border-hairline)",
              background: "var(--surface-panel)",
              paddingLeft: "var(--space-4)",
              paddingRight: "var(--space-4)",
              gap: "2px",
            }}
          >
            {TAB_ORDER.map((tab) => {
              const isActive = activeTab === tab;
              const nameInfo = tabNames[tab];

              return (
                <button
                  key={tab}
                  id={`tab-${tab}`}
                  role="tab"
                  aria-selected={isActive}
                  aria-controls="panel-workspace"
                  tabIndex={isActive ? 0 : -1}
                  type="button"
                  onClick={() => onTabChange(tab)}
                  className="h-full inline-flex items-center space-x-1.5 font-medium transition-colors shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-border-focus cursor-pointer"
                  style={{
                    padding: "0 12px",
                    borderBottom: isActive ? "2px solid var(--text-accent)" : "2px solid transparent",
                    color: isActive ? "var(--text-primary)" : "var(--text-muted)",
                    background: isActive ? "var(--surface-elevated)" : "transparent",
                    letterSpacing: "0.01em",
                  }}
                >
                  <span style={{ color: isActive ? "var(--text-accent)" : "var(--text-muted)" }}>
                    {tabIcons[tab]}
                  </span>
                  <span className="font-sans font-medium">{nameInfo.plain}</span>
                  <span className="text-[10px] opacity-75 font-mono">({nameInfo.technical})</span>
                  <span
                    className="tabular-nums text-[9px]"
                    style={{
                      padding: "0 4px",
                      borderRadius: "var(--radius-xs)",
                      background: isActive ? "var(--surface-ground)" : "transparent",
                      color: isActive ? "var(--text-secondary)" : "var(--text-muted)",
                      border: isActive ? "1px solid var(--border-hairline)" : "1px solid transparent",
                    }}
                  >
                    {getTabCount(tab)}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Primary Split Workspace */}
          <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
            {/* Left: Active Tab View */}
            <main
              id="panel-workspace"
              role="tabpanel"
              aria-labelledby={`tab-${activeTab}`}
              tabIndex={0}
              className="flex-1 flex flex-col min-h-0 overflow-y-auto focus:outline-none focus-visible:ring-1 focus-visible:ring-border-focus atlas-grid"
              style={{ background: "var(--surface-ground)" }}
            >
              {children}
            </main>

            {/* Right: Detail Inspector */}
            <aside
              aria-label="Entity and Evidence Detail Inspector"
              className="w-full lg:w-[460px] xl:w-[520px] h-96 lg:h-auto overflow-hidden shrink-0 border-t lg:border-t-0 lg:border-l border-hairline"
              style={{ background: "var(--surface-panel)" }}
            >
              <DetailInspector
                report={report}
                selectedChange={selectedChange}
                selectedTestChange={selectedTestChange}
                selectedCorrelation={selectedCorrelation}
                associatedEvidence={associatedEvidence}
                selectedEvidenceId={selectedEvidenceId}
                onSelectEvidence={onSelectEvidence}
              />
            </aside>
          </div>

          {/* Bottom Limitations Tray */}
          <LimitationsBanner report={report} />
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center p-8 atlas-grid">
          {children}
        </div>
      )}
    </div>
  );
};
