export function processPayment(payment: { valid: boolean; amount: number }): boolean {
  return payment.amount > 0;
}
