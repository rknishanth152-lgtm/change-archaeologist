/**
 * Change Archaeologist — How to Read This Report Guide
 *
 * A compact, dismissible, keyboard-accessible guide answering three core questions:
 * 1. What changed? (Structural code changes)
 * 2. What do the tests tell us? (Companion test changes & relationships)
 * 3. What can we conclude? (Evidence, limits of static analysis, epistemic boundaries)
 *
 * Integrated UI Components retrieved from:
 * - https://motion-primitives.com/c/disclosure.json (Animated Height Disclosure)
 * - https://motion-primitives.com/c/animated-group.json (Staggered Animation Entrance)
 * - https://buttons.ibelick.com/ (Tactile Micro-Interaction Buttons)
 * - https://ui.shadcn.com/r/styles/default/badge.json (Semantic Archival Badges)
 */

import React, { useState } from "react";
import {
  HelpCircle,
  X,
  Layers,
  FileCheck,
  Scale,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import type { AnalysisReport } from "../types/index.js";
import { buildReportReadingGuideData, CONCEPT_EXPLANATIONS } from "../utils/explanation-helpers.js";
import {
  Disclosure,
  DisclosureTrigger,
  DisclosureContent,
} from "./ui/Disclosure.js";
import { AnimatedGroup } from "./ui/AnimatedGroup.js";
import { TactileButton } from "./ui/TactileButton.js";
import { Badge } from "./ui/Badge.js";

interface ReportReadingGuideProps {
  readonly report: AnalysisReport;
  readonly isOpen: boolean;
  readonly onClose: () => void;
}

export const ReportReadingGuide: React.FC<ReportReadingGuideProps> = ({
  report,
  isOpen,
  onClose,
}) => {
  const [openSection1, setOpenSection1] = useState<boolean>(false);
  const [openSection2, setOpenSection2] = useState<boolean>(false);
  const [openSection3, setOpenSection3] = useState<boolean>(false);
  const [showGlossary, setShowGlossary] = useState<boolean>(false);

  const guideData = buildReportReadingGuideData(report);

  if (!isOpen) return null;

  return (
    <section
      role="region"
      aria-label="How to Read This Report Guide"
      className="border-b border-hairline bg-surface-elevated animate-fadeIn select-text"
      style={{
        background: "var(--surface-elevated)",
        borderColor: "var(--border-hairline)",
      }}
    >
      <div className="max-w-7xl mx-auto p-4 sm:p-5 space-y-4">
        {/* Header Bar */}
        <div className="flex items-start justify-between pb-3 border-b border-hairline">
          <div className="flex items-center space-x-2.5">
            <div
              className="w-7 h-7 rounded-sm flex items-center justify-center text-text-accent shrink-0"
              style={{ background: "var(--surface-ground)", border: "1px solid var(--border-hairline)" }}
              aria-hidden="true"
            >
              <HelpCircle size={15} strokeWidth={1.5} />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="font-display font-semibold text-sm text-text-primary">
                  How to Read This Report
                </h2>
                <Badge variant="sandstone">
                  Newcomer Guide
                </Badge>
              </div>
              <p className="font-body text-xs text-text-secondary mt-0.5">
                Understand what Change Archaeologist found in <code className="font-mono text-[11px] text-text-primary">{guideData.targetName}</code> between commits <code className="font-mono text-[10px] text-text-secondary">{guideData.commitRange}</code>.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <TactileButton
              variant="outline"
              size="xs"
              onClick={() => setShowGlossary(!showGlossary)}
              aria-expanded={showGlossary}
              aria-label={showGlossary ? "Hide glossary of terms" : "Show glossary of terms"}
            >
              {showGlossary ? "Hide Terms" : "Glossary"}
            </TactileButton>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xs hover:bg-surface-hover text-text-muted hover:text-text-primary focus:outline-none focus-visible:ring-2 focus-visible:ring-border-focus transition-colors cursor-pointer"
              aria-label="Dismiss How to Read This Report Guide"
              title="Dismiss Guide"
            >
              <X size={16} strokeWidth={1.5} />
            </button>
          </div>
        </div>

        {/* 3 Core Questions Grid with Motion-Primitives AnimatedGroup */}
        <AnimatedGroup preset="slide" stagger={0.06} className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {/* Question 1: What changed? */}
          <div
            className="rounded-md border border-hairline p-3.5 bg-ground flex flex-col justify-between space-y-3"
            style={{ borderColor: "var(--border-hairline)" }}
          >
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-hairline">
                <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-text-primary">
                  <Layers size={14} className="text-status-modified" />
                  <span>1. What changed?</span>
                </div>
                <Badge variant="terracotta">AST DIFF</Badge>
              </div>
              <div className="font-sans font-medium text-xs text-text-primary mt-2">
                Code Changes (Structural AST Mutations)
              </div>
              <p className="font-body text-xs text-text-secondary mt-1 leading-relaxed">
                {guideData.whatChanged.summary}
              </p>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-hairline">
              {guideData.whatChanged.details.map((detail, idx) => (
                <div key={idx} className="flex items-start space-x-1.5 text-[11px] font-mono text-text-secondary">
                  <span className="text-text-accent mt-0.5">•</span>
                  <span>{detail}</span>
                </div>
              ))}
            </div>

            {/* Motion-Primitives Disclosure for Question 1 details */}
            <Disclosure open={openSection1} onOpenChange={setOpenSection1}>
              <DisclosureTrigger>
                <button
                  type="button"
                  className="w-full text-[11px] font-mono text-text-accent flex items-center justify-between pt-1 hover:underline focus:outline-none focus-visible:ring-1 focus-visible:ring-border-focus cursor-pointer"
                  aria-expanded={openSection1}
                  aria-label="Toggle details for Question 1: What changed?"
                >
                  <span>{openSection1 ? "Hide AST details" : "Learn what AST mutation means"}</span>
                  {openSection1 ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
              </DisclosureTrigger>

              <DisclosureContent>
                <div className="p-2.5 mt-2 rounded-sm bg-panel border border-hairline text-[11px] font-body text-text-secondary space-y-1">
                  <p>
                    <strong>Abstract Syntax Tree (AST):</strong> Unlike a simple text diff that looks at lines and whitespace, an AST compares the parsed grammar of the code.
                  </p>
                  <p className="text-text-muted">
                    This catches meaningful structural shifts — such as a removed <code className="font-mono">if (...)</code> check or altered <code className="font-mono">return</code> value — while ignoring pure reformatting.
                  </p>
                </div>
              </DisclosureContent>
            </Disclosure>
          </div>

          {/* Question 2: What do the tests tell us? */}
          <div
            className="rounded-md border border-hairline p-3.5 bg-ground flex flex-col justify-between space-y-3"
            style={{ borderColor: "var(--border-hairline)" }}
          >
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-hairline">
                <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-text-primary">
                  <FileCheck size={14} className="text-status-strong" />
                  <span>2. What do the tests tell us?</span>
                </div>
                <Badge variant="verdigris">COMPANION TESTS</Badge>
              </div>
              <div className="font-sans font-medium text-xs text-text-primary mt-2">
                Related Tests & Assertions
              </div>
              <p className="font-body text-xs text-text-secondary mt-1 leading-relaxed">
                {guideData.whatTestsTellUs.summary}
              </p>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-hairline">
              {guideData.whatTestsTellUs.details.map((detail, idx) => (
                <div key={idx} className="flex items-start space-x-1.5 text-[11px] font-mono text-text-secondary">
                  <span className="text-status-strong mt-0.5">•</span>
                  <span>{detail}</span>
                </div>
              ))}
            </div>

            {/* Motion-Primitives Disclosure for Question 2 details */}
            <Disclosure open={openSection2} onOpenChange={setOpenSection2}>
              <DisclosureTrigger>
                <button
                  type="button"
                  className="w-full text-[11px] font-mono text-text-accent flex items-center justify-between pt-1 hover:underline focus:outline-none focus-visible:ring-1 focus-visible:ring-border-focus cursor-pointer"
                  aria-expanded={openSection2}
                  aria-label="Toggle details for Question 2: What do tests tell us?"
                >
                  <span>{openSection2 ? "Hide test details" : "Why companion tests matter"}</span>
                  {openSection2 ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
              </DisclosureTrigger>

              <DisclosureContent>
                <div className="p-2.5 mt-2 rounded-sm bg-panel border border-hairline text-[11px] font-body text-text-secondary space-y-1">
                  <p>
                    <strong>Companion Tests:</strong> When engineers change production code, they often commit corresponding test changes in the same commit.
                  </p>
                  <p className="text-text-muted">
                    We detect whether assertions were updated to match the new behavior, or if the code change went into production without any companion test updates.
                  </p>
                </div>
              </DisclosureContent>
            </Disclosure>
          </div>

          {/* Question 3: What can we conclude? */}
          <div
            className="rounded-md border border-hairline p-3.5 bg-ground flex flex-col justify-between space-y-3"
            style={{ borderColor: "var(--border-hairline)" }}
          >
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-hairline">
                <div className="flex items-center space-x-2 text-xs font-mono font-semibold text-text-primary">
                  <Scale size={14} className="text-text-secondary" />
                  <span>3. What can we conclude?</span>
                </div>
                <Badge variant="sandstone">EPISTEMIC LIMITS</Badge>
              </div>
              <div className="font-sans font-medium text-xs text-text-primary mt-2">
                What We Know & Epistemic Boundaries
              </div>
              <p className="font-body text-xs text-text-secondary mt-1 leading-relaxed">
                {guideData.whatWeCanConclude.summary}
              </p>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-hairline">
              {guideData.whatWeCanConclude.details.map((detail, idx) => (
                <div key={idx} className="flex items-start space-x-1.5 text-[11px] font-mono text-text-secondary">
                  <span className="text-text-secondary mt-0.5">•</span>
                  <span>{detail}</span>
                </div>
              ))}
            </div>

            {/* Motion-Primitives Disclosure for Question 3 details */}
            <Disclosure open={openSection3} onOpenChange={setOpenSection3}>
              <DisclosureTrigger>
                <button
                  type="button"
                  className="w-full text-[11px] font-mono text-text-accent flex items-center justify-between pt-1 hover:underline focus:outline-none focus-visible:ring-1 focus-visible:ring-border-focus cursor-pointer"
                  aria-expanded={openSection3}
                  aria-label="Toggle details for Question 3: What can we conclude?"
                >
                  <span>{openSection3 ? "Hide limits" : "Limits of static analysis"}</span>
                  {openSection3 ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                </button>
              </DisclosureTrigger>

              <DisclosureContent>
                <div className="p-2.5 mt-2 rounded-sm bg-panel border border-hairline text-[11px] font-body text-text-secondary space-y-1">
                  <p>
                    <strong>Epistemic Humility:</strong> Static analysis reads code without executing it.
                  </p>
                  <p className="text-text-muted">
                    A &quot;STRONG&quot; correlation means a test directly calls the changed function in the same commit — it does <span className="underline decoration-status-removed">not</span> prove the test passed or that a bug was fixed.
                  </p>
                </div>
              </DisclosureContent>
            </Disclosure>
          </div>
        </AnimatedGroup>

        {/* Optional Expandable Glossary Drawer */}
        {showGlossary && (
          <div className="p-4 rounded-md border border-hairline bg-ground space-y-3 font-mono text-xs animate-fadeIn">
            <div className="flex items-center justify-between pb-2 border-b border-hairline">
              <span className="font-semibold text-text-primary">GLOSSARY OF TERMS & STATUSES</span>
              <span className="text-[10px] text-text-muted">Definitions grounded in static analysis</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
              <div>
                <strong className="text-text-primary">{CONCEPT_EXPLANATIONS.strongStatus.term}:</strong>{" "}
                <span className="text-text-secondary font-body">{CONCEPT_EXPLANATIONS.strongStatus.plain}</span>
              </div>
              <div>
                <strong className="text-text-primary">{CONCEPT_EXPLANATIONS.weakStatus.term}:</strong>{" "}
                <span className="text-text-secondary font-body">{CONCEPT_EXPLANATIONS.weakStatus.plain}</span>
              </div>
              <div>
                <strong className="text-text-primary">{CONCEPT_EXPLANATIONS.uncertainStatus.term}:</strong>{" "}
                <span className="text-text-secondary font-body">{CONCEPT_EXPLANATIONS.uncertainStatus.plain}</span>
              </div>
              <div>
                <strong className="text-text-primary">{CONCEPT_EXPLANATIONS.noneStatus.term}:</strong>{" "}
                <span className="text-text-secondary font-body">{CONCEPT_EXPLANATIONS.noneStatus.plain}</span>
              </div>
              <div>
                <strong className="text-text-primary">{CONCEPT_EXPLANATIONS.astMutation.term}:</strong>{" "}
                <span className="text-text-secondary font-body">{CONCEPT_EXPLANATIONS.astMutation.plain}</span>
              </div>
              <div>
                <strong className="text-text-primary">{CONCEPT_EXPLANATIONS.evidenceAnchor.term}:</strong>{" "}
                <span className="text-text-secondary font-body">{CONCEPT_EXPLANATIONS.evidenceAnchor.plain}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
