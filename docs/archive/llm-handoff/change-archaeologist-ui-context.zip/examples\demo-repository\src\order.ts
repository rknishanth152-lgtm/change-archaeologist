export function calculateDiscount(price: number): number {
  if (price <= 0) {
    return 0;
  }
  return price * 0.15;
}
