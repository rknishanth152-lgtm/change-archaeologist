import React, { useState, useMemo, useCallback, useRef, useEffect } from "react";
import {
  ReactFlow,
  Controls,
  Background,
  MiniMap,
  useNodesState,
  useEdgesState,
  BackgroundVariant,
  type Node,
  type Edge,
  type ReactFlowInstance,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";

import {
  Network,
  ListFilter,
  Eye,
  AlertOctagon,
  Maximize2,
  Info,
  Check,
  X,
} from "lucide-react";
import type {
  AnalysisReport,
  CorrelationGraphNode,
  CorrelationGraphEdge,
} from "../types/index.js";
import { buildCorrelationGraphModel } from "../utils/graph-model.js";
import {
  explainCorrelation,
  explainStructuralChange,
  explainTestChange,
} from "../utils/explanation-helpers.js";
import {
  ProductionFunctionNode,
  StructuralChangeNode,
  TestChangeNode,
  TestDeclarationNode,
  TestFileNode,
} from "./graph/CustomNodes.js";
import { ContainmentEdge, CorrelationEdge } from "./graph/CustomEdges.js";
import { GraphLegend } from "./graph/GraphLegend.js";
import { Badge } from "./ui/Badge.js";
import { GraphAccessibleView } from "./graph/GraphAccessibleView.js";

// Custom node and edge type mapping
const nodeTypes = {
  productionFunction: ProductionFunctionNode,
  structuralChange: StructuralChangeNode,
  testChange: TestChangeNode,
  testDeclaration: TestDeclarationNode,
  testFile: TestFileNode,
};

const edgeTypes = {
  containment: ContainmentEdge,
  correlation: CorrelationEdge,
};

interface CorrelationGraphProps {
  readonly report: AnalysisReport;
  readonly selectedChangeId: string | null;
  readonly selectedTestChangeId: string | null;
  readonly selectedEvidenceId: string | null;
  readonly selectedCorrelationId: string | null;
  readonly onSelectChange: (changeId: string) => void;
  readonly onSelectTestChange: (testChangeId: string) => void;
  readonly onSelectEvidence: (evidenceId: string) => void;
  readonly onSelectCorrelation: (correlationId: string) => void;
}

export const CorrelationGraph: React.FC<CorrelationGraphProps> = ({
  report,
  selectedChangeId,
  selectedTestChangeId,
  selectedEvidenceId,
  selectedCorrelationId,
  onSelectChange,
  onSelectTestChange,
  onSelectEvidence,
  onSelectCorrelation,
}) => {
  const [viewMode, setViewMode] = useState<"visual" | "accessible">("visual");
  const [rfInstance, setRfInstance] = useState<ReactFlowInstance | null>(null);
  const [isExplainerDismissed, setIsExplainerDismissed] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Derive presentation graph model
  const model = useMemo(() => buildCorrelationGraphModel(report), [report]);

  // Derive plain-English explanation for currently selected graph item
  const activeExplanation = useMemo(() => {
    if (selectedCorrelationId) {
      const corr = report.correlationItems?.find((c) => c.id === selectedCorrelationId);
      if (corr) return explainCorrelation(corr, report.request.targetFunctionName);
    }
    if (selectedChangeId) {
      const sc = report.structuralChanges.find((s) => s.id === selectedChangeId);
      if (sc) return explainStructuralChange(sc, report.request.targetFunctionName);
    }
    if (selectedTestChangeId) {
      const tc = report.testChanges.find((t) => t.id === selectedTestChangeId);
      if (tc) return explainTestChange(tc, report.request.targetFunctionName);
    }
    return null;
  }, [report, selectedCorrelationId, selectedChangeId, selectedTestChangeId]);

  // Reset dismissed state whenever selection changes
  useEffect(() => {
    setIsExplainerDismissed(false);
  }, [selectedCorrelationId, selectedChangeId, selectedTestChangeId]);

  // Sync selected state onto nodes
  const initialNodes = useMemo(() => {
    return model.nodes.map((node) => {
      let isSelected = false;
      if (node.data.category === "STRUCTURAL_CHANGE") {
        isSelected = selectedChangeId === node.data.entityId;
      } else if (node.data.category === "TEST_CHANGE") {
        isSelected = selectedTestChangeId === node.data.entityId;
      }
      return {
        ...node,
        selected: isSelected,
      };
    });
  }, [model.nodes, selectedChangeId, selectedTestChangeId]);

  // Sync selected state onto edges
  const initialEdges = useMemo(() => {
    return model.edges.map((edge) => {
      let isSelected = false;
      if (edge.data.category === "CORRELATED_WITH" && selectedCorrelationId) {
        isSelected = edge.id.includes(selectedCorrelationId);
      }
      return {
        ...edge,
        selected: isSelected,
      };
    });
  }, [model.edges, selectedCorrelationId]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes as unknown as Node[]);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges as unknown as Edge[]);

  useEffect(() => {
    setNodes(initialNodes as unknown as Node[]);
  }, [initialNodes, setNodes]);

  useEffect(() => {
    setEdges(initialEdges as unknown as Edge[]);
  }, [initialEdges, setEdges]);

  // Automatically recalculate viewport when report changes or instance mounts
  useEffect(() => {
    if (!rfInstance) return;
    const isReduced = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const timer = setTimeout(() => {
      rfInstance.fitView({
        padding: 0.12,
        minZoom: 0.65,
        maxZoom: 1.15,
        duration: isReduced ? 0 : 250,
      });
    }, 60);
    return () => clearTimeout(timer);
  }, [rfInstance, report]);

  // Automatically recalculate viewport when container size changes
  useEffect(() => {
    if (!containerRef.current || !rfInstance) return;
    const ro = new ResizeObserver(() => {
      rfInstance.fitView({
        padding: 0.12,
        minZoom: 0.65,
        maxZoom: 1.15,
      });
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, [rfInstance]);

  // Responsive default: switch to Accessible View on narrow screens (< 768px)
  useEffect(() => {
    if (typeof window !== "undefined" && window.innerWidth < 768) {
      setViewMode("accessible");
    }
  }, []);

  // Node selection handler
  const handleNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      const graphNode = node as unknown as CorrelationGraphNode;
      if (graphNode.data.category === "STRUCTURAL_CHANGE") {
        onSelectChange(graphNode.data.entityId);
        if (graphNode.data.evidenceIds.length > 0) {
          onSelectEvidence(graphNode.data.evidenceIds[0]);
        }
      } else if (graphNode.data.category === "TEST_CHANGE") {
        onSelectTestChange(graphNode.data.entityId);
        if (graphNode.data.evidenceIds.length > 0) {
          onSelectEvidence(graphNode.data.evidenceIds[0]);
        }
      }
    },
    [onSelectChange, onSelectTestChange, onSelectEvidence]
  );

  // Edge selection handler
  const handleEdgeClick = useCallback(
    (_: React.MouseEvent, edge: Edge) => {
      const graphEdge = edge as unknown as CorrelationGraphEdge;
      if (graphEdge.data.category === "CORRELATED_WITH") {
        const matchedCorr = report.correlationItems?.find(
          (c) =>
            c.structuralChangeId === graphEdge.data.sourceEntityId &&
            c.testChangeId === graphEdge.data.targetEntityId
        );
        if (matchedCorr) {
          onSelectCorrelation(matchedCorr.id);
          if (matchedCorr.evidenceIds.length > 0) {
            onSelectEvidence(matchedCorr.evidenceIds[0]);
          }
        }
      }
    },
    [report.correlationItems, onSelectCorrelation, onSelectEvidence]
  );

  const handleFitView = useCallback(() => {
    const isReduced = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    rfInstance?.fitView({
      padding: 0.12,
      minZoom: 0.65,
      maxZoom: 1.15,
      duration: isReduced ? 0 : 250,
    });
  }, [rfInstance]);

  return (
    <div ref={containerRef} className="flex flex-col h-full bg-ground text-text-primary">
      {/* 1. Header Toolbar */}
      <div className="h-11 border-b border-hairline px-4 bg-panel flex items-center justify-between font-mono text-xs select-none shrink-0">
        <div className="flex items-center space-x-2">
          <Network size={15} className="text-text-accent" />
          <span className="font-semibold text-text-primary">
            Production-Test Correlation Graph
          </span>
          <span className="text-[10px] text-text-muted px-1.5 py-0.2 rounded-xs bg-ground border border-hairline hidden sm:inline-block">
            {report.baseCommit.sha.slice(0, 7)} → {report.headCommit.sha.slice(0, 7)}
          </span>
        </div>

        {/* View Mode Toggle, Fit View & Metrics */}
        <div className="flex items-center space-x-2">
          <span className="text-[11px] text-text-muted hidden md:inline-block tabular-nums">
            {model.summary.productionNodeCount} Prod / {model.summary.testNodeCount} Test /{" "}
            {model.summary.correlationEdgeCount} Corr
          </span>

          {viewMode === "visual" && (
            <button
              type="button"
              onClick={handleFitView}
              aria-label="Fit view to all nodes"
              className="px-2 py-0.5 rounded-xs transition-colors flex items-center space-x-1 text-text-muted hover:text-text-primary hover:bg-surface-elevated border border-hairline focus:outline-none focus-visible:ring-2 focus-visible:ring-border-focus"
              title="Reset viewport to fit all nodes cleanly"
            >
              <Maximize2 size={12} />
              <span>Fit View</span>
            </button>
          )}

          <div className="flex items-center bg-ground p-0.5 rounded-sm border border-hairline">
            <button
              type="button"
              onClick={() => setViewMode("visual")}
              aria-pressed={viewMode === "visual"}
              className={`px-2 py-0.5 rounded-xs transition-colors flex items-center space-x-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-border-focus ${
                viewMode === "visual"
                  ? "bg-surface-elevated text-text-primary font-semibold"
                  : "text-text-muted hover:text-text-secondary"
              }`}
            >
              <Eye size={12} />
              <span>Visual Graph</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode("accessible")}
              aria-pressed={viewMode === "accessible"}
              className={`px-2 py-0.5 rounded-xs transition-colors flex items-center space-x-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-border-focus ${
                viewMode === "accessible"
                  ? "bg-surface-elevated text-text-primary font-semibold"
                  : "text-text-muted hover:text-text-secondary"
              }`}
            >
              <ListFilter size={12} />
              <span>Accessible View</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Incomplete Analysis Banner (Scenario F) */}
      {model.isIncomplete && (
        <div className="m-3 p-3 rounded-md border border-status-removed-border bg-status-removed-bg text-text-primary font-mono text-xs flex items-center space-x-2.5 shrink-0">
          <AlertOctagon size={16} className="text-status-removed shrink-0" />
          <div>
            <span className="font-semibold">Comparative Analysis Incomplete:</span>{" "}
            <span className="text-text-secondary">{model.incompleteReason}</span>
          </div>
        </div>
      )}

      {/* 3. Main Graph Canvas or Accessible View */}
      <div className="flex-1 relative min-h-[500px] overflow-hidden">
        {viewMode === "accessible" ? (
          <div className="h-full overflow-y-auto">
            <GraphAccessibleView
              model={model}
              selectedNodeId={
                selectedChangeId
                  ? `node-sc-${selectedChangeId}`
                  : selectedTestChangeId
                  ? `node-tc-${selectedTestChangeId}`
                  : null
              }
              selectedEdgeId={selectedCorrelationId ? `edge-corr-${selectedCorrelationId}` : null}
              onSelectNode={(node) => {
                if (node.data.category === "STRUCTURAL_CHANGE") {
                  onSelectChange(node.data.entityId);
                  if (node.data.evidenceIds.length > 0) {
                    onSelectEvidence(node.data.evidenceIds[0]);
                  }
                } else if (node.data.category === "TEST_CHANGE") {
                  onSelectTestChange(node.data.entityId);
                  if (node.data.evidenceIds.length > 0) {
                    onSelectEvidence(node.data.evidenceIds[0]);
                  }
                }
              }}
              onSelectEdge={(edge) => {
                const matched = report.correlationItems?.find(
                  (c) =>
                    c.structuralChangeId === edge.data.sourceEntityId &&
                    c.testChangeId === edge.data.targetEntityId
                );
                if (matched) {
                  onSelectCorrelation(matched.id);
                  if (matched.evidenceIds.length > 0) {
                    onSelectEvidence(matched.evidenceIds[0]);
                  }
                }
              }}
              onSelectEvidence={onSelectEvidence}
            />
          </div>
        ) : (
          <div className="w-full h-full bg-ground relative">
            {/* Top Domain Guide Bar */}
            <div className="absolute top-3 left-4 right-4 z-10 pointer-events-none flex justify-between font-mono text-[10px] select-none text-text-muted">
              <div
                className="flex items-center space-x-2 px-2.5 py-1 rounded-xs"
                style={{
                  background: "var(--surface-panel)",
                  border: "1px solid var(--border-hairline)",
                  boxShadow: "0 1px 4px rgba(90, 70, 50, 0.08)",
                }}
              >
                <span className="w-2 h-2 rounded-full" style={{ background: "var(--text-accent)" }} />
                <span className="font-semibold text-text-primary uppercase tracking-wider">Production Domain</span>
                <span className="text-[9px] text-text-muted">({model.summary.productionNodeCount} nodes)</span>
              </div>
              <div
                className="flex items-center space-x-2 px-2.5 py-1 rounded-xs"
                style={{
                  background: "var(--surface-panel)",
                  border: "1px solid var(--border-hairline)",
                  boxShadow: "0 1px 4px rgba(90, 70, 50, 0.08)",
                }}
              >
                <span className="w-2 h-2 rounded-full" style={{ background: "var(--status-strong-fg)" }} />
                <span className="font-semibold text-text-primary uppercase tracking-wider">Test Domain</span>
                <span className="text-[9px] text-text-muted">
                  ({model.summary.testNodeCount} nodes
                  {model.summary.testNodeCount === 0 ? " — no companion tests" : ""})
                </span>
              </div>
            </div>

            {/* Selected Entity Plain-English Explainer Card */}
            {activeExplanation && !isExplainerDismissed && (
              <div
                role="region"
                aria-label="Selected entity explanation card"
                className="absolute top-12 left-4 z-20 w-80 max-w-[calc(100vw-2rem)] rounded-md border border-hairline bg-panel/95 backdrop-blur-sm p-3 font-mono text-xs shadow-md space-y-2 select-text"
                style={{
                  background: "var(--surface-panel)",
                  borderColor: "var(--border-hairline)",
                }}
              >
                <div className="flex items-center justify-between pb-1.5 border-b border-hairline">
                  <div className="flex items-center space-x-1.5 truncate">
                    <Info size={13} className="text-text-accent shrink-0" />
                    <span className="font-sans font-semibold text-xs text-text-primary truncate">
                      {activeExplanation.plainTitle}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1 shrink-0 ml-1">
                    {activeExplanation.technicalBadge && (
                      <Badge variant="outline" className="text-[9px] px-1 py-0">
                        {activeExplanation.technicalBadge}
                      </Badge>
                    )}
                    <button
                      type="button"
                      onClick={() => setIsExplainerDismissed(true)}
                      className="p-0.5 text-text-muted hover:text-text-primary rounded-xs focus:outline-none focus-visible:ring-1 focus-visible:ring-border-focus cursor-pointer"
                      aria-label="Dismiss selection explanation card"
                      title="Dismiss card"
                    >
                      <X size={12} />
                    </button>
                  </div>
                </div>

                <p className="font-body text-[11px] text-text-secondary leading-normal">
                  {activeExplanation.whatChanged}
                </p>

                <div className="grid grid-cols-1 gap-1 pt-1.5 border-t border-hairline text-[10px]">
                  <div className="text-text-secondary">
                    <strong className="text-status-strong">✓ Establishes: </strong>
                    <span className="font-body text-text-muted">{activeExplanation.establishes}</span>
                  </div>
                  <div className="text-text-secondary">
                    <strong className="text-status-removed">✕ Does not establish: </strong>
                    <span className="font-body text-text-muted">{activeExplanation.doesNotEstablish}</span>
                  </div>
                </div>
              </div>
            )}

            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onNodeClick={handleNodeClick}
              onEdgeClick={handleEdgeClick}
              onInit={setRfInstance}
              nodeTypes={nodeTypes}
              edgeTypes={edgeTypes}
              fitView
              fitViewOptions={{ padding: 0.12, minZoom: 0.65, maxZoom: 1.15 }}
              minZoom={0.35}
              maxZoom={2.0}
              className="change-archaeologist-flow"
              aria-label="Interactive Production-Test Correlation Graph"
            >
              <Background
                variant={BackgroundVariant.Lines}
                gap={32}
                size={1}
                color="rgba(90, 70, 50, 0.08)"
              />
              <Controls
                className="!bg-panel !border-hairline !rounded-sm !shadow-md [&>button]:!bg-panel [&>button]:!border-hairline [&>button]:!text-text-secondary hover:[&>button]:!bg-surface-elevated"
              />
              <MiniMap
                nodeColor={(node) => {
                  switch (node.type) {
                    case "productionFunction":
                      return "#C4521A";
                    case "structuralChange":
                      return "#E65100";
                    case "testChange":
                      return "#2E7D32";
                    case "testDeclaration":
                      return "#5C3D99";
                    case "testFile":
                      return "#1A5C2E";
                    default:
                      return "#8A7560";
                  }
                }}
                className="!bg-panel !border-hairline !rounded-sm hidden sm:block"
                maskColor="rgba(245, 240, 232, 0.75)"
              />
            </ReactFlow>

            {/* Floating Legend */}
            <GraphLegend summary={model.summary} />
          </div>
        )}
      </div>
    </div>
  );
};
