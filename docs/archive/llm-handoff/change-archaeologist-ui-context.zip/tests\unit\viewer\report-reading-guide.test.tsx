// @vitest-environment jsdom
/**
 * Change Archaeologist — How to Read This Report Guide Unit Tests
 *
 * Verifies newcomer guide rendering, 3 core questions, grounded metrics,
 * glossary toggle, dismissal, and accessibility.
 */

import React from "react";
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";

import { ReportReadingGuide } from "../../../src/viewer/components/ReportReadingGuide.js";
import { ExecutiveSummaryStrip } from "../../../src/viewer/components/ExecutiveSummaryStrip.js";
import { DetailInspector } from "../../../src/viewer/components/DetailInspector.js";
import {
  DEMO_SCENARIO_A,
  DEMO_SCENARIO_E,
} from "../../../src/viewer/data/demo-fixtures.js";

// Mock Monaco for JSDOM
vi.mock("@monaco-editor/react", () => ({
  DiffEditor: (props: any) => (
    <div data-testid="monaco-diff-editor">
      <div>{props.original}</div>
      <div>{props.modified}</div>
    </div>
  ),
  loader: { config: vi.fn() },
}));

describe("ReportReadingGuide & Newcomer Comprehension", () => {
  beforeEach(() => {
    cleanup();
  });

  afterEach(() => {
    cleanup();
  });

  it("renders when isOpen is true and displays the 3 core questions", () => {
    const handleClose = vi.fn();

    render(
      <ReportReadingGuide
        report={DEMO_SCENARIO_E}
        isOpen={true}
        onClose={handleClose}
      />
    );

    // Guide Header & Tag
    expect(screen.getByText("How to Read This Report")).toBeInTheDocument();
    expect(screen.getByText("Newcomer Guide")).toBeInTheDocument();

    // The 3 core questions
    expect(screen.getByText("1. What changed?")).toBeInTheDocument();
    expect(screen.getByText("2. What do the tests tell us?")).toBeInTheDocument();
    expect(screen.getByText("3. What can we conclude?")).toBeInTheDocument();

    // Plain English subtitles
    expect(screen.getByText("Code Changes (Structural AST Mutations)")).toBeInTheDocument();
    expect(screen.getByText("Related Tests & Assertions")).toBeInTheDocument();
    expect(screen.getByText("What We Know & Epistemic Boundaries")).toBeInTheDocument();

    // Grounded details for Scenario E
    expect(screen.getByText(/We compared function 'calculateDiscount'/)).toBeInTheDocument();
    expect(screen.getByText(/We searched for test changes committed in the same revision range/)).toBeInTheDocument();
    expect(screen.getByText(/Static analysis inspects code structure in Git; it does NOT run the tests/)).toBeInTheDocument();
  });

  it("does not render when isOpen is false", () => {
    render(
      <ReportReadingGuide
        report={DEMO_SCENARIO_E}
        isOpen={false}
        onClose={vi.fn()}
      />
    );

    expect(screen.queryByText("How to Read This Report")).not.toBeInTheDocument();
  });

  it("calls onClose when the dismiss button is clicked", () => {
    const handleClose = vi.fn();

    render(
      <ReportReadingGuide
        report={DEMO_SCENARIO_E}
        isOpen={true}
        onClose={handleClose}
      />
    );

    const closeBtn = screen.getByLabelText("Dismiss How to Read This Report Guide");
    fireEvent.click(closeBtn);
    expect(handleClose).toHaveBeenCalledTimes(1);
  });

  it("toggles the glossary of terms drawer", () => {
    render(
      <ReportReadingGuide
        report={DEMO_SCENARIO_E}
        isOpen={true}
        onClose={vi.fn()}
      />
    );

    const glossaryBtn = screen.getByRole("button", { name: /Show glossary of terms/i });
    expect(screen.queryByText("GLOSSARY OF TERMS & STATUSES")).not.toBeInTheDocument();

    fireEvent.click(glossaryBtn);
    expect(screen.getByText("GLOSSARY OF TERMS & STATUSES")).toBeInTheDocument();
    expect(screen.getByText(/STRONG Correlation:/)).toBeInTheDocument();
  });

  it("renders the 'How to Read This Report' trigger button in ExecutiveSummaryStrip and fires onToggleGuide", () => {
    const handleToggle = vi.fn();

    render(
      <ExecutiveSummaryStrip
        report={DEMO_SCENARIO_E}
        isGuideOpen={false}
        onToggleGuide={handleToggle}
      />
    );

    const guideBtn = screen.getByRole("button", { name: /Open How to Read This Report Guide/i });
    expect(guideBtn).toBeInTheDocument();
    fireEvent.click(guideBtn);
    expect(handleToggle).toHaveBeenCalledTimes(1);
  });

  it("renders plain-English explanation card with 'Establishes' and 'Does NOT Establish' in DetailInspector", () => {
    const sc = DEMO_SCENARIO_A.structuralChanges[0];

    render(
      <DetailInspector
        report={DEMO_SCENARIO_A}
        selectedChange={sc}
        selectedCorrelation={null}
        associatedEvidence={DEMO_SCENARIO_A.evidence}
      />
    );

    // Plain-English Explanation region
    const explanationRegion = screen.getByRole("region", { name: "Plain-English Explanation" });
    expect(explanationRegion).toBeInTheDocument();

    expect(screen.getByText("Defensive Safety Check Removed")).toBeInTheDocument();
    expect(screen.getByText("Establishes")).toBeInTheDocument();
    expect(screen.getByText("Does NOT Establish")).toBeInTheDocument();
    expect(screen.getByText(/The syntax tree of this function was structurally altered/)).toBeInTheDocument();
    expect(screen.getByText(/Whether this change caused a bug/)).toBeInTheDocument();
  });

  it("renders plain-English explanation for a selected test change in DetailInspector", () => {
    const tc = DEMO_SCENARIO_E.testChanges[0];

    render(
      <DetailInspector
        report={DEMO_SCENARIO_E}
        selectedChange={null}
        selectedTestChange={tc}
        selectedCorrelation={null}
        associatedEvidence={DEMO_SCENARIO_E.evidence}
      />
    );

    expect(screen.getByText("Test Calling Changed Function")).toBeInTheDocument();
    expect(screen.getByText(/directly invokes or references 'calculateDiscount'/)).toBeInTheDocument();
    expect(screen.getByText(/Whether this test was executed during CI\/CD/)).toBeInTheDocument();
  });
});

